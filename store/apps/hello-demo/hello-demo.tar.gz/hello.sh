#!/bin/sh
# reBoard store demo app: waits a bit so the launcher hand-off is visible,
# then exits (the daemon shows the board again automatically).
sleep 20
