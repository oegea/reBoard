#!/bin/sh
# reBoard store demo app: intentionally headless. It pauses briefly (the
# board image stays on the e-paper) and exits; the daemon then shows the
# board again. Its only purpose is validating install/uninstall.
sleep 5
