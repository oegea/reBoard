name=Hello Demo
exec={APP_DIR}/hello.sh
